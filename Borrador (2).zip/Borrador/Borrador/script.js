alert("HOLA, SCRIPT FUNCIONA");

// ============================
// CÓDIGOS QR DE LA LÍNEA DE TIEMPO
// ============================

function generarQR(id, pagina) {

    const contenedor = document.getElementById(id);

    if (!contenedor) {
        console.log("No existe:", id);
        return;
    }

    const direccion = new URL(pagina, window.location.href).href;

    new QRCode(contenedor, {
        text: direccion,
        width: 120,
        height: 120,
        colorDark: "#222222",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });
}


// QR del año 1979
generarQR("qr1979", "Años/1979.html");

// QR del año 1980
generarQR("qr1980", "Años/1980_1981.html");

// QR del año 1988
generarQR("qr1988", "Años/1988.html");
